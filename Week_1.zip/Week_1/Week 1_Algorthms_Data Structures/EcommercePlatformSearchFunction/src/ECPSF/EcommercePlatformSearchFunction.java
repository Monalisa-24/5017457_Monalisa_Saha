package ECPSF;
import java.util.Scanner;

public class EcommercePlatformSearchFunction {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		Product[] products = {
			new Product(1, "Goodday", "Biscuits"),
			new Product(2, "Amul Hazelnut", "Chocolate"),
			new Product(3, "Maggie", "Noodles"),
			new Product(4, "Black Forest", "Ice Cream"),
			new Product(5, "Potato", "Vegetable")
		};
		
		
		
		while(true) {
			System.out.println("\nMenu : ");
			System.out.println("---------------");
			System.out.println("1. Linear Search");
			System.out.println("2. Binary Search");
			System.out.println("3. Exit");
			
			System.out.print("Enter your choice : ");
			int choice = sc.nextInt();
			sc.nextLine();
			
			switch(choice) {
			case 1: System.out.println("\nLinear Search");
					System.out.println("-------------");
					LinearSearch ls = new LinearSearch(products, "Maggie");
					
					Product searchResult = ls.search();
					if(searchResult == null) {
						System.out.print("Product does not exist!");
					}else {
						System.out.print("Product found - "+searchResult);
					}
				break;
			case 2: System.out.println("\n\nBinary Search");
					System.out.println("--------------");
	
					Searching bs = new BinarySearch(products, "Goodday");
					Product searchResult1 = bs.search();
					if(searchResult1 == null) {
						System.out.print("Product does not exist!");
					}else {
						System.out.print("Product found - "+searchResult1);
					}
					break;
			case 3: System.exit(0);
			default: System.out.println("Invalid option.");
					 break;
				
			}
						
		}
	}

}
