package EMS;

public class EmployeeManagementSystem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Operation op = new Operation();
		
		// creating objects of Employee
		Employee e1 = new Employee(1, "Monalisa Saha", "Java Developer", 45000);
		Employee e2 = new Employee(2, "Nandini Saha", "HR Manager", 25000);
		Employee e3 = new Employee(3, "Aritra Hazra", "System Engineer", 38000);
		
		// initializing an empty array
		Employee[] employees = new Employee[0];
		
		
		// traversing array at the beginning : that will display empty, hence no employee is added
		Employee[] all = op.traverseEmployee(employees);
		if(all.length == 0) {
			System.out.println("Employee list is empty!");
		}else {
			for(Employee emps : all) {
				System.out.println(emps);
			}
		}
		
		// adding employees to the array
		employees = op.addEmployee(employees, e1);
		employees = op.addEmployee(employees, e2);
		employees = op.addEmployee(employees, e3);
		
		System.out.println("\n3 new employees are added!\n");
		
		
		// traversing the array
		System.out.println("Display Employees : ");
		System.out.println("------------------- ");
		all = op.traverseEmployee(employees);
		if(all.length == 0) {
			System.out.println("Employee list is empty!");
		}else {
			for(Employee emps : all) {
				System.out.println(emps);
			}
		}
		
		
		// searching employee with id 2
		System.out.println("\nSearching Employees : ");
		System.out.println("--------------------- ");
		Employee emp = op.searchEmployee(employees, 2);
		if(emp == null) {
			System.out.println("Employee not found!");
		}else {
			System.out.println("Employee with id 2 has been found."+emp+"\n");
		}
		
		
		
		// searching employee with id 3
		System.out.println("Deleting Employees : ");
		System.out.println("--------------------");
		employees = op.deleteEmployee(employees, 3);
		System.out.println("Employee with id 3 has been deleted.\n");
		all = op.traverseEmployee(employees);
		
		// after deleting employee with id 3, traversing the array again
		System.out.println("Now the employee list is : ");
		System.out.println("--------------------------");
		if(all.length == 0) {
			System.out.println("Employee list is empty!");
		}else {
			for(Employee emps : all) {
				System.out.println(emps);
			}
		}

	}

}
