package EMS;

public class Operation {
	

	public Employee[] addEmployee(Employee[] employees, Employee newEmployee) {
        Employee[] newEmployees = new Employee[employees.length + 1];
        System.arraycopy(employees, 0, newEmployees, 0, employees.length);
        newEmployees[employees.length] = newEmployee;
        return newEmployees;
    }
	
	public Employee searchEmployee(Employee[] employees, int empId) {
		if(employees.length == 0) {
			return null;
		}else {
			for(Employee empItems : employees) {
				if(empItems.getEmployeeId() == empId) {
					return empItems;
				}
			}
		}
		return null;
	}

	public Employee[] traverseEmployee(Employee[] employees) {
		return employees;
	}

	public Employee[] deleteEmployee(Employee[] employees, int empId) {
        if (employees.length == 0) {
            return employees;
        } else {
            int index = -1;
            for (int i = 0; i < employees.length; i++) {
                if (employees[i].getEmployeeId() == empId) {
                    index = i;
                    break;
                }
            }
            if (index != -1) {
                Employee[] newEmployees = new Employee[employees.length - 1];
                for (int i = 0, j = 0; i < employees.length; i++) {
                    if (i != index) {
                        newEmployees[j++] = employees[i];
                    }
                }
                return newEmployees;
            } else {
                return employees;
            }
        }
	}
}
