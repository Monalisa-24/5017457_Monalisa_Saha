package SCO;

public abstract class Sorting {
	public abstract Order[] sort(Order[] orders);
}


class BubbleSort extends Sorting{

	@Override
	public Order[] sort(Order[] orders) {
		int lastIndex = orders.length - 1;
		
		for(int i=0; i<lastIndex; i++) {
			for(int j=0; j<lastIndex - i; j++) {
				if(orders[j].getTotalPrice() > orders[j+1].getTotalPrice()) {
					Order temp = orders[j];
					orders[j] = orders[j+1];
					orders[j+1] = temp;
				}
			}
		}
		return orders;
	}
	
}


class QuickSort extends Sorting{

	@Override
	public Order[] sort(Order[] orders) {
		quickSort(orders, 0, orders.length - 1);
		return orders;
	}
	
	public void quickSort(Order[] orders, int lower, int upper) {
		if(lower < upper) {
			int mid = partition(orders, lower, upper);
			quickSort(orders, lower, mid-1);
			quickSort(orders, mid+1, upper);
		}
	}
	
	public int partition(Order[] orders, int lower, int upper) {
		int pivot = orders[upper].getTotalPrice();
		int index = lower - 1;
		for(int j=lower; j<upper; j++) {
			if(orders[j].getTotalPrice() <= pivot) {
				index++;
				Order temp = orders[index];
				orders[index] = orders[j];
				orders[j] = temp;
			}
		}
		Order temp = orders[index+1];
		orders[index+1] = orders[upper];
		orders[upper] = temp;
		
		return index+1;
	}
}