package SCO;
import java.util.Scanner;

public class SortingCustomerOrders {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Order[] orders = {
			new Order(1, "Monalisa Saha", 1200),
			new Order(2, "Nandini Saha", 200),
			new Order(3, "Neha Saha", 1265),
			new Order(4, "Aysarya Saha", 1550),
			new Order(5, "Kanika Saha", 700),
			new Order(6, "Anima Saha", 150)
		};
				
		while(true) {
			System.out.println("\n--------");
			System.out.println("  Menu ");
			System.out.println("--------");
			System.out.println("1. Bubble Sort");
			System.out.println("2. Quick Sort");
			System.out.println("3. Exit");
					
			System.out.print("Enter a option : ");
			int choice = sc.nextInt();
					
			switch(choice) {
				case 1: Sorting bubbleSort = new BubbleSort();
						if(orders.length == 0) {
							System.out.println("No orders exist!\n");
						}else {
							for(Order orderItem : bubbleSort.sort(orders)) {
								System.out.println(orderItem);
							}
						}
					break;
						
				case 2: Sorting quickSort = new QuickSort();
						if(orders.length == 0) {
							System.out.println("No orders exist!\n");
						}else {
							for(Order orderItem : quickSort.sort(orders)) {
								System.out.println(orderItem);
							}
							}
					break;
						
				case 3: System.exit(0);
					break;
						
				default: System.out.println("Please enter a valid option!\n");
					break;
				}
				
			}

		}
}
