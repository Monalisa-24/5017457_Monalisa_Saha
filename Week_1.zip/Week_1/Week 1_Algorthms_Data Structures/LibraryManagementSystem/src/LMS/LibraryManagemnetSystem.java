package LMS;

import java.util.Scanner;


public class LibraryManagemnetSystem {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		Book[] books = {
				new Book(1, "Pather Panchali", "BB"),
				new Book(2, "Durgesnandini" ,"BC"),
				new Book(3, "Sesher Kobita", "RT"),
				new Book(4, "Mejdidi", "SC"),
				new Book(5, "Dipnirban", "SKD")
		};
		
		while(true) {
			System.out.println("\nMenu : ");
			System.out.println("---------------");
			System.out.println("1. Linear Search");
			System.out.println("2. Binary Search");
			System.out.println("3. Exit");
			
			System.out.print("Enter your choice : ");
			int choice = sc.nextInt();
			sc.nextLine();
			
			switch(choice) {
			case 1: System.out.println("\nLinear Search");
					System.out.println("-------------");
					LinearSearch ls = new LinearSearch(books, "Sesher Kobita");
					
					Book searchResult = ls.search();
					if(searchResult == null) {
						System.out.print("Book does not exist!");
					}else {
						System.out.print("Book found - "+searchResult);
					}
				break;
			case 2: System.out.println("\n\nBinary Search");
					System.out.println("--------------");
					
					Searching bs = new BinarySearch(books, "Durgesnandini");
					Book searchResult1 = bs.search();
					if(searchResult1 == null) {
						System.out.print("Book does not exist!");
					}else {
						System.out.print("Book found - "+searchResult1);
					}
					break;
			case 3: System.exit(0);
			default: System.out.println("Invalid option.");
					 break;
				
			}
						
		}
	}

}


