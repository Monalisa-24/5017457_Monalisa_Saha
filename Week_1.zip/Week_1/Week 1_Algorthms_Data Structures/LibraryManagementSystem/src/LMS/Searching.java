package LMS;

import java.util.Arrays;

abstract class Searching {
	protected Book[] books;
	protected String title;
	
	
	public Searching(Book[] books, String title) {
		this.books = books;
		this.title = title;
	}
	


	public abstract Book search();
}

class LinearSearch extends Searching {
	public LinearSearch(Book[] books, String title) {
		super(books, title);
	}

	@Override
	public Book search() {
		for(Book bItem : books) {
			if(bItem.getTitle().equalsIgnoreCase(title)) {
				return bItem;
			}
		}
		return null;
	}
}

class BinarySearch extends Searching{
	public BinarySearch(Book[] books, String title) {
		super(books, title);
		Arrays.sort(this.books, (b1, b2) -> b1.getTitle().compareToIgnoreCase(b2.getTitle()));
	}

	@Override
	public Book search() {
		int lower = 0;
		int upper = books.length - 1;
		
		
		while(lower <= upper) {
			int mid = (lower + upper)/2;
			int result = books[mid].getTitle().compareToIgnoreCase(title);
	
			
			if(result == 0) {
				return books[mid];
			}else if(result < 0) {
				lower = mid+1; 
			}
			else {
				upper = mid-1;
			}
		}
		return null;
	}
}
