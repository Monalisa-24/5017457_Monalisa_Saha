package IMS;
import java.util.HashMap;
import java.util.Map;


public class InventoryManager {
	private Map<Object, Product> p;
	
	public InventoryManager() {
		this.p = new HashMap<>();
	}
	
	
	public void addProduct(Product product) {
		if(p.containsKey(product.getProductId())) {
			System.out.println("Product Id already exists!");
		}else {
			p.put(product.getProductId(), product);
		}
	}
	
	public void updateProduct(String productId, Product update_product) {
		if(p.containsKey(productId)) {
			p.put(productId, update_product);
		}else {
			System.out.println("Product is not found!");
		}
	}
	
	public void deleteProduct(String productId) {
		if(p.containsKey(productId)) {
			p.remove(productId);
		}else {
			System.out.println("Product is not found!");
		}
	}
	
	public boolean displayProduct(String productId) {
			if(p.containsKey(productId)) {
				Product pItem = p.get(productId);
				System.out.println("\nProduct Id:  "+pItem.getProductId()+
						   "\nProduct Name: "+pItem.getProductName()+
						   "\nQuantity: "+pItem.getQuantity()+
						   "\nPrice: "+pItem.getPrice()
						   );
				return true;
			}else {
				return false;
			}
	}
		
	
	public void displayAllProducts() {
		if(p.isEmpty()) {
			System.out.println("No products found!\n");
		}else {
		for(Product pItem : p.values()) {
			System.out.println("\nProduct Id:  "+pItem.getProductId()+
					   "\nProduct Name: "+pItem.getProductName()+
					   "\nQuantity: "+pItem.getQuantity()+
					   "\nPrice: "+pItem.getPrice()
					   );
		}
		}
	}
	
	public Product exist_Product(String productId) {
		return p.get(productId);
	}
}

