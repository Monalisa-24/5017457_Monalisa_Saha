package IMS;
import java.util.Scanner;

public class InventoryManagementSystem {

	public static void main(String[] args) {
		InventoryManager im = new InventoryManager();
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			System.out.println("\n-----------");
			System.out.println("Operation :");
			System.out.println("-----------");
			System.out.println("1. Add Product");
			System.out.println("2. Update Product");
			System.out.println("3. Delete Product");
			System.out.println("4. Display a Product by productId");
			System.out.println("5. Display all products");
			System.out.println("6. Exit");
			
			System.out.print("Enter a choice : ");
			int choice = sc.nextInt();
			sc.nextLine();
			String pId, pName;
			int quan;
			double price;
			
			switch(choice) {
			case 1: System.out.print("Enter productId : ");
					pId = sc.nextLine();
					System.out.print("Enter productName : ");
					pName = sc.nextLine();
					System.out.print("Enter quantity : ");
					quan = sc.nextInt();
					System.out.print("Enter price : ");
					price = sc.nextDouble();
					sc.nextLine();
					im.addProduct(new Product(pId, pName, quan, price));
					break;
					
					
			case 2: System.out.print("Enter productId : ");
					pId = sc.nextLine();
					if(im.exist_Product(pId) == null) {
						System.out.println("No products found!\n");
					}else {
						System.out.print("Enter productName : ");
						pName = sc.nextLine();
						System.out.print("Enter quantity : ");
						quan = sc.nextInt();
						System.out.print("Enter price : ");
						price = sc.nextDouble();
						sc.nextLine();
						im.updateProduct(pId, new Product(pId, pName, quan, price));
					}
					break;
					
			case 3: System.out.print("Enter productId : ");
					pId = sc.nextLine();
					im.deleteProduct(pId);
					break;
					
			case 4: System.out.println("Product Details : ");
					System.out.println("-----------------");
					System.out.print("Enter productId : ");
					pId = sc.nextLine();
					im.displayProduct(pId);
					if(im.exist_Product(pId) == null) {
						System.out.println("Product not found!\n");
					}
					break;
					
			case 5: System.out.println("\n-------------------------");
					System.out.println("Displaying All Products : ");
					System.out.println("-------------------------");
					im.displayAllProducts();
					break;
				
			case 6: System.exit(0);
			
			default : System.out.println("Please enter a valid option : ");
					  break;
			}
		}
		
	}

}
