package SPE;

public class Logger {
	private static Logger logger;

    private Logger() {}

    public static Logger getInstance(){
        if(logger == null){
            logger = new Logger();
        }
        return logger;
    }

    public int instanceHashCode() {
    	return System.identityHashCode(this);
    }
    public void info(String info){
        System.out.println("Logger : "+info);
    }
}
