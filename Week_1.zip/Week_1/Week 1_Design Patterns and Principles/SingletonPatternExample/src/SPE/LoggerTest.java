package SPE;

public class LoggerTest {
	public static void main(String[] args) {
		Logger logger1 = Logger.getInstance();
        Logger logger2 = Logger.getInstance();
        
        logger1.info("This is information 1.");
        System.out.println("Logger1 : Hashcode = "+logger1.instanceHashCode());      
        
        logger2.info("This is information 2.");
        System.out.println("Logger2 : Hashcode = "+logger2.instanceHashCode()); 
        
        if(logger1.instanceHashCode() == logger2.instanceHashCode()) {
        	System.out.println("yes, both the hashcodes are same.");
        }else {
        	System.out.println("no, the hashcodes are not same.");
        }
    }
}
