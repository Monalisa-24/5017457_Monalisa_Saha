package OPE;

public class ObserverPatternExample {

	public static void main(String[] args) {
		StockMarket stockMarket = new StockMarket();

        Observer ma1 = new MobileApp("MA1");
        Observer ma2 = new MobileApp("MA2");
        Observer wa1 = new WebApp("WA1");

        stockMarket.registerObserver(ma1);
        stockMarket.registerObserver(ma2);
        stockMarket.registerObserver(wa1);

        stockMarket.setStockPrice("ABC", 157850.00);
        stockMarket.setStockPrice("xyz", 28410700.00);

        stockMarket.deregisterObserver(ma2);

        stockMarket.setStockPrice("ABC", 985412.00);

	}

}
