package FMPE;

public class FactoryMethodPatternExample {

	public static void main(String[] args) {
		DocumentFactory excelDocumentFactory = new ExcelDocumentFactory();
		Document excelDocument = excelDocumentFactory.createDocument();
		
		DocumentFactory pdfDocumentFactory = new PdfDocumentFactory();
		Document pdfDocument = pdfDocumentFactory.createDocument();
		
		DocumentFactory wordDocumentFactory = new WordDocumentFactory();
		Document wordDocument = wordDocumentFactory.createDocument();
		
		Tester tester = new Tester();
		
		
		System.out.println("First Type Document : ");
		System.out.println("---------------------\n");
		System.out.println("Format type : "+excelDocument.FormatType());
		tester.testApplication("Excel Format", excelDocument.FormatType()); 
		System.out.println("Is empty ? " +excelDocument.isEmpty());	
		tester.testApplication("No", excelDocument.isEmpty());
		System.out.println("Author : "+excelDocument.author());
		tester.testApplication("Nandini", excelDocument.author());
				
		
		System.out.println("\nSecond Type Document : ");
		System.out.println("------------------------\n");
		System.out.println("Format type : "+pdfDocument.FormatType());
		tester.testApplication("Pdf Format", pdfDocument.FormatType());
		System.out.println("Is empty ? "+pdfDocument.isEmpty());
		tester.testApplication("Yes", pdfDocument.isEmpty());
		System.out.println("Author : "+pdfDocument.author());
		tester.testApplication("Rocky", pdfDocument.author());
		
		
		System.out.println("\nThird Type Document : ");
		System.out.println("-----------------------\n");
		System.out.println("Format type : "+wordDocument.FormatType());
		tester.testApplication("Word Format", wordDocument.FormatType());
		System.out.println("Is empty ? "+wordDocument.isEmpty());
		tester.testApplication("No", wordDocument.isEmpty());
		System.out.println("Author : "+wordDocument.author());
		tester.testApplication("Monalisa", wordDocument.author());
	}

}
