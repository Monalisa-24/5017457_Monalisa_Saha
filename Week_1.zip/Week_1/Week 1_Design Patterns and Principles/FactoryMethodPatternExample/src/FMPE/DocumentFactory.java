package FMPE;

public abstract class DocumentFactory {
	public abstract Document createDocument();
}

class ExcelDocumentFactory extends DocumentFactory{
	
	@Override
	public Document createDocument() {
		return new ExcelDocument();
	}
	
}

class PdfDocumentFactory extends DocumentFactory{
	
	@Override
	public Document createDocument() {
		return new PdfDocument();
	}
	
}


class WordDocumentFactory extends DocumentFactory{
	
	@Override
	public Document createDocument() {
		return new WordDocument();
	}
	
}
