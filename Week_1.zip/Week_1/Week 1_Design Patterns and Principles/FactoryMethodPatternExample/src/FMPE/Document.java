package FMPE;

public interface Document {
	public String FormatType();
	public String isEmpty();
	public String author();
}


class ExcelDocument implements Document {

	@Override
	public String FormatType() {
		return "Excel Format";
	}

	@Override
	public String isEmpty() {
		return "No";
	}

	@Override
	public String author() {
		return "Nandini";
	}
}


class PdfDocument implements Document {

	@Override
	public String FormatType() {
		return "Pdf Format";
	}

	@Override
	public String isEmpty() {
		return "Yes";
	}

	@Override
	public String author() {
		return "Rocky";
	}
}

class WordDocument implements Document {

	@Override
	public String FormatType() {
		return "Word Format";
	}

	@Override
	public String isEmpty() {
		return "No";
	}

	@Override
	public String author() {
		return "Monalisa";
	}

}
