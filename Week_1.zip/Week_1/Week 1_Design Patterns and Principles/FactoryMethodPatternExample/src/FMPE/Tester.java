package FMPE;

public class Tester {
	public void testApplication(String para1, String para2) {
		if(para1.equals(para2)) {
			System.out.println("Yeah, Testing is successful.\n");
		}else {
			System.out.println("oh, Testing is not successful.\n");
		}
	}
}
