package MVCPE;
import java.util.Scanner;

public class MVCPatternExample {
	
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		Student s = new Student("Monalisa Saha", 2, "A");
		StudentView sv = new StudentView(s);
		StudentController sc = new StudentController(s, sv);
		
		Tester tester = new Tester();
		
		// Details of the Student
		System.out.println("\nDetails of the Student below : \n------------------------------\n");
		sv.displayStudentDetails();
		
		// Updating the details
		System.out.println("\nUpdating Student : \n---------------------------");
		
		
		while(true) {
			System.out.println("\n1. Update Name\n");
			System.out.println("2. Update Id\n");
			System.out.println("3. Update Grade\n");
			System.out.println("4. Show Updated Student\n");
			System.out.println("5. Exit \n");
			
			System.out.print("Choose an option : ");
			int option = scanner.nextInt();
			
			scanner.nextLine();
			
			switch(option) {
			case 1: 
					sc.update_StudentName("Nandini Saha");
					System.out.println("\nName of the updated Student below : \n--------------------------------------\n");
					System.out.println(sc.displayUpdatedStudentDetails_Name());
					tester.testApplication("Nandini Saha", sc.displayUpdatedStudentDetails_Name());
					break;
					
			case 2: 
					sc.update_StudentId(2);
					System.out.println("\nId of the updated Student below : \n--------------------------------------\n");
					System.out.println(sc.displayUpdatedStudentDetails_Id());
					tester.testApplication(2, sc.displayUpdatedStudentDetails_Id());
					break;
					
			case 3: 
					sc.update_StudentGrade("O");
					System.out.println("\nGrade of the updated Student below : \n--------------------------------------\n");
					System.out.println(sc.displayUpdatedStudentDetails_Grade());
					tester.testApplication("O", sc.displayUpdatedStudentDetails_Grade());
					break;
					
			case 4:
					System.out.println("\nShow the updated Student below : \n--------------------------------------\n");
					sc.displayUpdatedStudentDetails();
					break;
					
			case 5: System.exit(0);
			
			default: System.out.println("Please enter a valid option.\n");
					 break;
			}
		}
	}
}
