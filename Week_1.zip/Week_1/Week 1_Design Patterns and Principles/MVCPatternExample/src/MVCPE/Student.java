package MVCPE;

public class Student {
	String name;
	int id;
	String grade;
	
	
	public Student(String n, int i, String g) {
		this.name = n;
		this.id = i;
		this.grade = g;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public int getId() {
		return id;
	}
	
	public void setGrade(String grade) {
		this.grade = grade;
	}
	
	public String getGrade() {
		return grade;
	}
}
