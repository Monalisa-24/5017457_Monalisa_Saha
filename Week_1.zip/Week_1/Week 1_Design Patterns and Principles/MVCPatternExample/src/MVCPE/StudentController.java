package MVCPE;

public class StudentController {
	private Student student;
	private StudentView view;

	public StudentController(Student student, StudentView view) {
		this.student = student;
		this.view = view;
	}
	
	public void update_StudentName(String newName) {
		student.setName(newName);
	}
	
	public void get_update_StudentName(String newName) {
		student.getName();
	}
	
	public String displayUpdatedStudentDetails_Name() {
		return student.getName();
	}
	
	public void update_StudentId(int newId) {
		student.setId(newId);
	}
	
	public void get_update_StudentId(int newId) {
		student.getId();
	}
	
	public int displayUpdatedStudentDetails_Id() {
		return student.getId();
	}
	
	public void update_StudentGrade(String newGrade) {
		student.setGrade(newGrade);
	}
	
	public void get_update_StudentGrade(String newGrade) {
		student.getGrade();
	}
	
	public String displayUpdatedStudentDetails_Grade() {
		return student.getGrade();
	}
	

	public void displayUpdatedStudentDetails() {
		view.displayStudentDetails(student.getName(), student.getId(), student.getGrade());
	}
}
