package CPM;

public class Tester {
	public void testApplication(String para1, String para2) {
		if(para1.equals(para2)) {
			System.out.println("Yeah, Testing is successful!\n");
		}else {
			System.out.println("Oh, Testing is unsuccessful!\n");
		}
	}
}
