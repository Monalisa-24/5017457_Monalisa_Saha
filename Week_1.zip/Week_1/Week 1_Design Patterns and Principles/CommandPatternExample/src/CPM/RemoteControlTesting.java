package CPM;

public class RemoteControlTesting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Create the receiver object
        Light light_in_room = new Light();

        // Create command objects
        Command on = new LightOnCommand(light_in_room);
        Command off = new LightOffCommand(light_in_room);

        // Create invoker object
        RemoteControl rc = new RemoteControl();
        
        Tester tester = new Tester();

        // Turn the light on
        rc.setCommand(on);
        rc.getCommand(on);
        String display = rc.button();
        System.out.println(display);
        // Testing       
        tester.testApplication("Light On!", display);

        // Turn the light off
        rc.setCommand(off);
        rc.getCommand(off);
        display = rc.button();
        System.out.println(display);
        // Testing
        tester.testApplication("Light Off!", display);
	}

}
