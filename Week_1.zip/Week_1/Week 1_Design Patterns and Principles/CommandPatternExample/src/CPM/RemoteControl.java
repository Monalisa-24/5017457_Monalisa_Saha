package CPM;

public class RemoteControl {
	private Command c;
	
	public void setCommand(Command c) {
		this.c = c;
	}
	public void getCommand(Command c) {
		System.out.println("Command : "+c);
	}
	
	public String button() {
		return c.execute();
	}
}
