package CPM;

public class Light {
	public String turnon() {
		return "Light On!";
	}
	
	public String turnoff() {
		return "Light Off!";
	}
}
