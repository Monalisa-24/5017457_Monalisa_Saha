package CPM;

public class LightOnCommand implements Command {
	private Light l;
	
	public LightOnCommand(Light l) {
		this.l = l;
	}
	@Override
	public String execute() {
		return l.turnon();
	}
	
	@Override
	public String toString() {
		return "Switch on the light!";
	}
}
