package CPM;


public interface Command {
	String execute();
}
