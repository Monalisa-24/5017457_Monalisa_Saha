package APM;

public class PaytmGateway {
	public void paytmPayment(String paymentMethod, double amount){
        System.out.println("Payment processing Paytm : "+paymentMethod+", Amount = "+amount);
    }
}
