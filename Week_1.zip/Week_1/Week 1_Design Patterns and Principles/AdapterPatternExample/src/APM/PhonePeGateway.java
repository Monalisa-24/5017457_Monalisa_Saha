package APM;

public class PhonePeGateway {
	public void phonePePayment(String paymentMethod, double amount){
        System.out.println("Payment processing PhonePe : "+paymentMethod+", Amount = "+amount);
    }
}
