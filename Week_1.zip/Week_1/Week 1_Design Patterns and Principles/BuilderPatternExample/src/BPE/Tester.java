package BPE;

public class Tester {
	public void testApplication(String para1, String para2) {
		if(para1.equals(para2)) {
			System.out.println("Yeah, Testing is successful!\n");
		}else {
			System.out.println("Oh, Testing is not successful!\n");
		}
	}
	
	public void testApplication(int para1, int para2) {
		if(para1==para2) {
			System.out.println("Yeah, Testing is successful!\n");
		}else {
			System.out.println("Oh, Testing is not successful!\n");
		}
	}
}
