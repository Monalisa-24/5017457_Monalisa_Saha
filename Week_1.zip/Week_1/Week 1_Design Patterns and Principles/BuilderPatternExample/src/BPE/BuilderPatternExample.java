package BPE;

public class BuilderPatternExample {

	public static void main(String[] args) {
		Computer comp1 = new Computer.Builder("intel i5 gen8", 8, "1 TB HDD").build();
		
		Tester tester = new Tester();
		
		
		System.out.println("My Computer Configuration : ");
		System.out.println("---------------------------\n");
		
		System.out.println("CPU : "+comp1.getCPU());
		tester.testApplication("intel i5 gen8", comp1.getCPU());
		
		System.out.println("RAM : "+comp1.getRam());
		tester.testApplication(12, comp1.getRam());
		
		System.out.println("STORAGE : "+comp1.getStorage());
		tester.testApplication("1 TB HDD", comp1.getStorage());
	}

}
