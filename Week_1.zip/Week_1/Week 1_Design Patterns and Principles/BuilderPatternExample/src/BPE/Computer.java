package BPE;

public class Computer {
	String cpu;
	int ram;
	String storage;
	
	private Computer(Builder builder) {
		this.cpu = builder.cpu;
		this.ram = builder.ram;
		this.storage = builder.storage;
	}
	
	
	public String getCPU() {
		return cpu;
	}
	
	public int getRam() {
		return ram;
	}
	
	public String getStorage() {
		return storage;
	}



	public static class Builder{
		private String cpu;
		private int ram;
		private String storage;
		
		public Builder(String cpu, int ram, String storage) {
			this.cpu = cpu;
			this.ram = ram;
			this.storage = storage;
		}
		
		public Computer build() {
			return new Computer(this);
		}
}
}