package PPE;

public interface Image {
	void display();
}
