package PPE;

public class ProxyPatternExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Image image1 = new ProxyImage("image1.jpg");
        Image image2 = new ProxyImage("image2.jpg");

        // Image will be loaded from remote server
        image1.display();
        System.out.println("");

        // Image will not be loaded from remote server, it will use the cached one
        image1.display();
        System.out.println("");

        // Image will be loaded from remote server
        image2.display();
        System.out.println("");

        // Image will not be loaded from remote server, it will use the cached one
        image2.display();
    }
}
