package SPE;

public class StrategyPatternExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PaymentContext context = new PaymentContext();

        // Pay using Credit Card
        PaymentStrategy creditCardPayment = new CreditCardPayment("Monalisa Saha", "9874256314589852", "114", "03/26");
        context.setPaymentStrategy(creditCardPayment);
        context.pay(10.00);

        // Pay using PayPal
        PaymentStrategy payPalPayment = new PayPalPayment("monalisa256@example.com", "mona@256");
        context.setPaymentStrategy(payPalPayment);
        context.pay(25000.00);
	}

}
