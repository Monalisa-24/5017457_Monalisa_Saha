package DPE;

public class NotifierTesting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Notifier emailNotifier = new EmailNotifier();

        // Decorator with SMS and Slack notifier

        Notifier smsNotifier = new SMSNotifierDecorator(emailNotifier);

        Notifier slackNotifier = new SlackNotifierDecorator(smsNotifier);

        slackNotifier.send("This is a notifier....");
    }
}
