package DIE;

public class DependencyInjectionTesting {
	public static void main(String[] args) {
        CustomerRepository customerRepository = new CustomerRepositoryImpl();

        CustomerService customerService = new CustomerService(customerRepository);

        int customerId = 1;
        Customer customer = customerService.findCustomerById(customerId);

        System.out.println("Customer found:");
        System.out.println("ID: " + customer.getId());
        System.out.println("Name: " + customer.getName());
        System.out.println("Email: " + customer.getEmail());
        System.out.println("Age: " + customer.getAge());
    }
}
