package DIE;

public class CustomerRepositoryImpl implements CustomerRepository {
	@Override
    public Customer findCustomerById(int id) {
        return new Customer(id, "Monalisa", "monalisa256@gmail.com", 22);
    }
}
