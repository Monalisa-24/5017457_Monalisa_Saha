package com.library.repository;

public class BookRepository {
	public void displayRepository() {
        System.out.println("This is a Book Repository class.");
    }
}
