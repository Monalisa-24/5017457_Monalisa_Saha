package com.library.service;

public class BookService {
    public void displayService() {
        System.out.println("This is a Book Service class.");
    }
}
