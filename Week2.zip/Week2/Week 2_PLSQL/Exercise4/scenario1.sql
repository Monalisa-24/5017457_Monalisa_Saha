CREATE OR REPLACE FUNCTION CalculateAge (p_DOB DATE) RETURN NUMBER IS
    v_Age NUMBER;
BEGIN
    -- Calculating the age
    v_Age := FLOOR((SYSDATE - p_DOB) / 365.25);
    RETURN v_Age;
EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
END;
/



-- DECLARE
--     v_Age NUMBER;
-- BEGIN
--     v_Age := CalculateAge(TO_DATE('1985-05-15', 'YYYY-MM-DD'));
--     DBMS_OUTPUT.PUT_LINE('Age: ' || v_Age);
-- END;
-- /

