CREATE OR REPLACE TRIGGER CheckTransactionRules
BEFORE INSERT ON Transactions
FOR EACH ROW
DECLARE
    v_Balance Accounts.Balance%TYPE;
BEGIN
    
    SELECT Balance INTO v_Balance FROM Accounts WHERE AccountID = :NEW.AccountID;
    
    
    IF :NEW.TransactionType = 'Withdrawal' THEN
        
        IF :NEW.Amount > v_Balance THEN
            RAISE_APPLICATION_ERROR(-20001, 'Withdrawal amount exceeds the account balance.');
        END IF;
    ELSIF :NEW.TransactionType = 'Deposit' THEN
        
        IF :NEW.Amount <= 0 THEN
            RAISE_APPLICATION_ERROR(-20002, 'Deposit amount must be positive.');
        END IF;
    ELSE
        
        RAISE_APPLICATION_ERROR(-20003, 'Unknown transaction type.');
    END IF;
END;
/



-- BEGIN
--     -- Valid deposit
--     BEGIN
--         INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
--         VALUES (TransactionID_seq.NEXTVAL, 1, SYSDATE, 100, 'Deposit');
--         DBMS_OUTPUT.PUT_LINE('Deposit successful.');
--     EXCEPTION
--         WHEN OTHERS THEN
--             DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
--     END;
    
--     -- Invalid withdrawal (exceeds balance)
--     BEGIN
--         INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
--         VALUES (TransactionID_seq.NEXTVAL, 1, SYSDATE, 2000, 'Withdrawal');
--         DBMS_OUTPUT.PUT_LINE('Withdrawal successful.');
--     EXCEPTION
--         WHEN OTHERS THEN
--             DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
--     END;
    
--     -- Invalid deposit (negative amount)
--     BEGIN
--         INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
--         VALUES (TransactionID_seq.NEXTVAL, 1, SYSDATE, -50, 'Deposit');
--         DBMS_OUTPUT.PUT_LINE('Deposit successful.');
--     EXCEPTION
--         WHEN OTHERS THEN
--             DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
--     END;
-- END;
-- /

-- -- Enable output
-- SET SERVEROUTPUT ON;
