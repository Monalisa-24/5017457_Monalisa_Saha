package com.project.projection;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.project.Entity.Department;


@EnableJpaRepositories
@Repository
public interface DepartmentRepository extends JpaRepository<Department, Integer> {
	
	@Query("from Department where name= :name")
	public Department findByName(@Param ("name") String name);
	
	
	@Query("SELECT d.id AS id, d.name AS name  FROM Department d")
    List<DepartmentProjection> findDepartmentProjections();

    @Query("SELECT new com.project.projection.DepartmentSummary(d.id, d.name) FROM Department d")
    List<DepartmentSummary> findDepartmentSummaries(@Param("name") String name);
	
}
