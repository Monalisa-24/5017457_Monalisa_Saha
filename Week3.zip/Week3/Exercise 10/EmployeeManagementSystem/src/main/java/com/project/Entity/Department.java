package com.project.Entity;

import java.util.List;
import jakarta.persistence.*;
import lombok.Data;


@Data
@Entity
@Table(name = "department")
public class Department extends Auditable{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String name;
	@OneToMany(mappedBy ="department", cascade=CascadeType.ALL, fetch = FetchType.LAZY)
	private List<Employee> employees;
	
	public Department() {
		
	}
	
	public Department(int id2, String name2) {
		this.id=id2;
		this.name=name2;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Employee> getEmployees() {
		return employees;
	}
	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}

	@Override
	public String toString() {
		return "Department [id=" + id + ", name=" + name + ", employees=" + employees + "]";
	}
	
	
}
