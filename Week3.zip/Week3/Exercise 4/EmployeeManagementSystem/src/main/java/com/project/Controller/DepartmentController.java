package com.project.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.project.Entity.Department;
import com.project.Repository.DepartmentRepository;

@RestController
@RequestMapping("/department")
public class DepartmentController {
	
	@Autowired
	private DepartmentRepository departmentRepository;
	
	@PostMapping
	public Department createDepartment(@RequestBody Department department) {
		Department dept = new Department(
				department.getId(),
				department.getName()
		);
		System.out.println(department);
		return departmentRepository.save(dept);
	}
	
	@GetMapping
	public List<Department> getAllDepartments(){
		return departmentRepository.findAll();
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Department> getDepertmentById(@PathVariable int id) {
		if(departmentRepository.existsById(id)) {
			return new ResponseEntity(departmentRepository.findById(id), HttpStatus.OK);
		}else {
			return new ResponseEntity<Department>(HttpStatus.NOT_FOUND);
		}
	}

	
	@PutMapping("/{id}")
	public String updateDepartment(@PathVariable int id, @RequestBody Department department){
		if(departmentRepository.existsById(id)) {
			departmentRepository.save(department);
			return "Department updated successfully.";
		}else {
			return "No matches found!";
		}
	}
	
	@DeleteMapping("/{id}")
	public String deleteDepartment(@PathVariable int id) {
		if(departmentRepository.existsById(id)) {
			departmentRepository.deleteById(id);
			return "Department deleted successfully.";
		}
		return "No matches found!";
	}
	
}
	
