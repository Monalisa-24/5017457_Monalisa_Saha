package com.project.Repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.project.Entity.Department;
import com.project.Entity.Employee;



@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
	
	@Query("FROM Employee e WHERE e.name = :name")
	List<Employee> findByName(@Param ("name") String name);
	
	@Query("SELECT e FROM Employee e WHERE e.department = :department")
    List<Employee> findByDepartment(@Param("department") Department department);
	
	Page<Employee> findByName(String name, Pageable pageable);
	
	Page<Employee> findAll(Pageable pageable);
	
}
