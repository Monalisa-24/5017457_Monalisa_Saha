package com.project.Controller;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.Entity.Department;
import com.project.Entity.Employee;
import com.project.Repository.DepartmentRepository;
import com.project.Repository.EmployeeRepository;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Autowired
	private DepartmentRepository departmentRepository;
	
		
	
	@GetMapping("/all")
	public List<Employee> getAllEmployees(){
		return employeeRepository.findAll();
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable int id) {
		if(employeeRepository.existsById(id)) {
			return new ResponseEntity(employeeRepository.findById(id), HttpStatus.OK);
	}else {
		return new ResponseEntity<Employee>(HttpStatus.NOT_FOUND);
		}
	}
	
	
		
	@PostMapping
	public Employee createEmployee(@RequestBody Employee employee) {
	    Employee emp = new Employee(
	    		employee.getId(),
	    		employee.getName(),
	    		employee.getEmail(),
	    		employee.getDepartment()
	    		);
	    		System.out.println(employee);
	    		return employeeRepository.save(emp);
	}

	
	@PutMapping("/{id}")
	public String updateEmployee(@PathVariable int id, @RequestBody Employee employee) {
		if(employeeRepository.existsById(id)) {
			employeeRepository.save(employee);
			return "Employee updated successfully.";
		}else {
			return "No matches found with this particular id!";
			}
		}
	
	@DeleteMapping("/{id}")
		public String deleteEmployee(@PathVariable int id) {
			if(employeeRepository.existsById(id)) {
				employeeRepository.deleteById(id);
				return "Employee deleted successfully.";
			}else {
				return "No matches found with this particular id!";
			}
	}
	
	@GetMapping("/employeeName/{name}")
    public ResponseEntity<List<Employee>> findByName(@PathVariable String name) {
        List<Employee> employees = employeeRepository.findByName(name);
        
        if (employees.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
        return ResponseEntity.ok(employees);
    }
	
	@GetMapping("/employeesInDepartment/{id}")
    public ResponseEntity<List<Employee>> getEmployeesByDepartment(@PathVariable int id) {
        Department department = departmentRepository.findById(id).orElse(null);
        
        if (department == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
        List<Employee> employees = employeeRepository.findByDepartment(department);
        if (employees.isEmpty()) {
            return ResponseEntity.ok(Collections.emptyList());
        }
        return ResponseEntity.ok(employees);
    }
	
	@GetMapping
    public ResponseEntity<Page<Employee>> getEmployees(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir) {

        Pageable pageable = PageRequest.of(page, size,
                sortDir.equalsIgnoreCase("asc") ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending());

        Page<Employee> employees = employeeRepository.findAll(pageable);
        return ResponseEntity.ok(employees);
    }

    // Get employees by name with pagination and sorting
    @GetMapping("/employeeName_Page/{name}")
    public ResponseEntity<Page<Employee>> findByName(
            @PathVariable String name,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir) {

        Pageable pageable = PageRequest.of(page, size,
                sortDir.equalsIgnoreCase("asc") ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending());

        Page<Employee> employees = employeeRepository.findByName(name, pageable);

        if (employees.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Page.empty(pageable));
        }

        return ResponseEntity.ok(employees);
    }
	
	
}
